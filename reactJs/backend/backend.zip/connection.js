require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    mongoose.set("strictQuery", false);
    mongoose.connect("mongodb://127.0.0.1:27017/portfolio", {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    
    console.log("database  connected successfully ");
  } catch (error) {
    console.log("database  can not connected to the database "+error);
  }
};
module.exports = connectDB;



