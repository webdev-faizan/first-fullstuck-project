import React from 'react'

const UserInfo = () => {
  return (
    <div>
      <h1>this is user info</h1>
    </div>
  )
}

export default UserInfo
