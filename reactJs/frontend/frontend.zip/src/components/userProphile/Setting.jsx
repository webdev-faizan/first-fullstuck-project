import React from "react";

const Setting = () => {
  return (
    <div>
      <h1>this is setting page</h1>
    </div>
  );
};

export default Setting;
