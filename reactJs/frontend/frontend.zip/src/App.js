import React, { useEffect, useState } from "react";
import { Cookies } from "react-cookie";
import "./App.css";
import "./Stylesheet/auth.css";
import AuthRoutes from "./Routes/AuthRoutes";
import IndexRoutes from "./Routes/IndexRoutes";
import { useNavigate, useLocation } from "react-router-dom";
import { GoogleLogin } from "react-google-login";
import { GoogleLogout } from "react-google-login";
import { gapi } from "gapi-script";
import axios from "axios";

const App = () => {
  const [AuthenticateRoute, setAuthenticateRoute] = useState(false);
  const redirectHome = useNavigate();
  const location = useLocation();
  useEffect(() => {
    const cookie = new Cookies();
    let verifed = cookie.get("jwt");
    if (verifed) {
      // redirectHome("/prophile");
      redirectHome("/");
      setAuthenticateRoute(true);
    } else {
      redirectHome("/login");
      // setAuthenticateRoute(true);
    }
  }, []);
  const responseGoogle = (response) => {
    console.log(response, "faizan");
  };
  const faile = (e) => {
    console.log(e);
  };
  // useEffect(() => {
  //   function start() {
  //     gapi.client.init({
  //       clientId:
  //         "57664316633-j7i7juosi15m24dgj01d2bipo5loplhr.apps.googleusercontent.com",
  //       scope: "email",
  //     });
  //   }
  //   gapi.load("client:auth2", start);

  // console.log('insied useeffect')
  // }, []);

  return <>{AuthenticateRoute ? <IndexRoutes /> : <AuthRoutes />}</>;
};

export default App;
// const { signIn, loaded } = useGoogleLogin({
//   onSuccess,
//   onAutoLoadFinished,
//   clientId,
//   cookiePolicy,
//   loginHint,
//   hostedDomain,
//   autoLoad,
//   isSignedIn,
//   fetchBasicProfile,
//   redirectUri,
//   discoveryDocs,
//   onFailure,
//   uxMode,
//   scope,
//   accessType,
//   responseType,
//   jsSrc,
//   onRequest,
//   prompt
// })
