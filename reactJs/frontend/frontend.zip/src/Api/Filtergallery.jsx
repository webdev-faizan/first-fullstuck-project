const filtergallery = [


    {
        id: '1',
        title: 'App 1',
        subtitle: 'App',
        catageray: 'app',
        pic: './images/portfolio-1.jpg'

    },
    {
        id: '2',
        title: 'App 2',
        subtitle: 'App',
        catageray: 'app',
        pic: './images/./portfolio-3.jpg'

    },
    {
        id: '3',
        title: 'App 3',
        subtitle: 'App',
        subtitle: 'App',
        catageray: 'app',
        pic: './images/portfolio-6.jpg'

    },
    {
        id: '4',
        title: 'Card 1',
        subtitle: 'Card',
        catageray: 'card',
        pic: './images/portfolio-4.jpg'

    },
    {
        id: '5',
        title: 'Card 2',
        subtitle: 'Card',
        catageray: 'card',
        pic: './images/portfolio-8.jpg'

    },

    {
        id: '6',
        title: 'Card 3',
        subtitle: 'Card',
        catageray: 'card',
        pic: './images/portfolio-7.jpg'

    },

    {
        id: '7',
        title: 'Web 1',
        subtitle: 'Web',
        catageray: 'web',
        pic: './images/portfolio-2.jpg'

    },
    {
        id: '8',
        title: 'Web 2',
        subtitle: 'Web',
        catageray: 'web',
        pic: './images/portfolio-5.jpg'

    },
    {
        id: '9',
        title: 'Web 3',
        subtitle: 'Web',
        catageray: 'web',
        pic: './images/portfolio-9.jpg'

    }


]
export default filtergallery;