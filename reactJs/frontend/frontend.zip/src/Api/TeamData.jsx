const TeamData = [
    {
        src: './images/team-1.jpg',
        name: 'Walter White',
        profession: 'Chief Executive Officer',
        description: 'Velit aut quia fugit et et. Dolorum ea voluptate vel tempore tenetur ipsa quae aut. Ipsum exercitationem iure minima enim corporis et voluptate.'

    },

    {
        src: './images/team-2.jpg',
        name: 'Sarah Jhonson',
        profession: 'Product Manager',
        description: 'Quo esse repellendus quia id. Est eum et accusantium pariatur fugit nihil minima suscipit corporis. Voluptate sed quas reiciendis animi neque sapiente.'

    },

    {
        src: './images/team-3.jpg',
        name: 'William Anderson',
        profession: 'CTO',
        description: 'Vero omnis enim consequatur. Voluptas consectetur unde qui molestiae deserunt. Voluptates enim aut architecto porro aspernatur molestiae modi'

    },
    {
        src: './images/team-4.jpg',
        name: 'Amanda Jepson',
        profession: 'Accountant',
        description: 'Rerum voluptate non adipisci animi distinctio et deserunt amet voluptas. Quia aut aliquid doloremque ut possimus ipsum officia.'

    },



]

export default TeamData